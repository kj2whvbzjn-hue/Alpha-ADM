from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from .zip_importer import ImportLimits


@dataclass(frozen=True)
class RuntimeConfig:
    limits: ImportLimits = ImportLimits()
    buffer_size: int = 1024 * 1024
    log_level: str = 'INFO'


def load_config(path: str | Path | None) -> RuntimeConfig:
    if path is None:
        return RuntimeConfig()
    raw = json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(raw, dict):
        raise ValueError('設定ファイルはJSONオブジェクトにしてください。')
    limits_raw = raw.get('limits', {})
    if not isinstance(limits_raw, dict):
        raise ValueError('limits はJSONオブジェクトにしてください。')
    allowed_limits = set(asdict(ImportLimits()))
    unknown_limits = set(limits_raw) - allowed_limits
    if unknown_limits:
        raise ValueError(f'未対応のlimits設定です: {sorted(unknown_limits)}')
    limits = ImportLimits(**limits_raw)
    buffer_size = int(raw.get('buffer_size', 1024 * 1024))
    if buffer_size < 4096 or buffer_size > 16 * 1024 * 1024:
        raise ValueError('buffer_size は4096〜16777216の範囲で指定してください。')
    log_level = str(raw.get('log_level', 'INFO')).upper()
    if log_level not in {'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'}:
        raise ValueError('log_level が不正です。')
    return RuntimeConfig(limits=limits, buffer_size=buffer_size, log_level=log_level)
