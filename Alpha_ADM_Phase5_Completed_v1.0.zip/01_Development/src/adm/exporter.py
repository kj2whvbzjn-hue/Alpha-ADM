from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from pathlib import Path, PurePosixPath

from .classifier import ClassificationRecord, DEFAULT_CATEGORIES

_FIXED_ZIP_TIME = (2020, 1, 1, 0, 0, 0)


def _effective_category(record: ClassificationRecord) -> str:
    return record.confirmed_category or record.proposed_category


def _unique_destination(folder: Path, original_path: str, used: set[str]) -> Path:
    name = PurePosixPath(original_path.replace('\\', '/')).name or 'unnamed'
    stem, suffix = Path(name).stem, Path(name).suffix
    candidate = folder / name
    index = 2
    while candidate.as_posix().casefold() in used:
        candidate = folder / f'{stem}_{index}{suffix}'
        index += 1
    used.add(candidate.as_posix().casefold())
    return candidate


def _write_reproducible_zip(source_root: Path, zip_path: Path) -> None:
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted((p for p in source_root.rglob('*') if p.is_file()), key=lambda p: p.relative_to(source_root).as_posix()):
            name = path.relative_to(source_root).as_posix()
            info = zipfile.ZipInfo(name, date_time=_FIXED_ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as fh:
        while chunk := fh.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def export_organized_package(package_root: str | Path, records: list[ClassificationRecord]) -> dict:
    root = Path(package_root)
    organized = root / 'organized'
    if organized.exists():
        shutil.rmtree(organized)
    organized.mkdir(parents=True)

    used: set[str] = set()
    exported: list[dict] = []
    by_id = {record.document_id: record for record in records}
    manifest = json.loads((root / '_ADM' / 'manifest.json').read_text(encoding='utf-8'))

    for file_info in manifest.get('files', []):
        record = by_id[file_info['sha256']]
        category = _effective_category(record)
        relative_destination = _unique_destination(
            Path(DEFAULT_CATEGORIES[category]), file_info['original_path'], used
        )
        destination = organized / relative_destination
        destination.parent.mkdir(parents=True, exist_ok=True)
        source = root / file_info['extracted_path']
        shutil.copyfile(source, destination)
        exported.append({
            'document_id': record.document_id,
            'original_path': record.original_path,
            'category': category,
            'organized_path': relative_destination.as_posix(),
            'sha256': file_info['sha256'],
        })

    index = {'schemaVersion': '2.0', 'fileCount': len(exported), 'files': exported}
    (organized / '_ADM').mkdir(exist_ok=True)
    (organized / '_ADM' / 'organization_index.json').write_text(
        json.dumps(index, ensure_ascii=False, indent=2, sort_keys=True), encoding='utf-8'
    )

    zip_path = root / f"{manifest['packageId']}_organized.zip"
    if zip_path.exists():
        zip_path.unlink()
    _write_reproducible_zip(organized, zip_path)

    return {
        'organizedDirectory': str(organized),
        'organizedArchive': str(zip_path),
        'organizedArchiveSha256': _sha256(zip_path),
        'organizedFileCount': len(exported),
        'reproducible': True,
    }
