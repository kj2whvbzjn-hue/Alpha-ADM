from __future__ import annotations

import csv
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath


DEFAULT_CATEGORIES = {
    "GOV": "00_Governance",
    "DEV": "01_Development",
    "AUD": "02_Organization_Audit",
    "REQ": "03_Requirements",
    "DES": "04_Architecture",
    "TST": "05_Test",
    "REL": "06_Release",
    "ARC": "07_Archive",
    "UNK": "99_Unclassified",
}

RULES = [
    ("GOV", ["governance", "policy", "charter", "approval", "basic_plan", "方針", "承認", "基本計画", "ガバナンス"]),
    ("AUD", ["audit", "quality", "inspection", "監査", "品質", "検査"]),
    ("REQ", ["requirement", "requirements", "specification", "要件", "要求仕様", "仕様書"]),
    ("DES", ["architecture", "design", "schema", "設計", "アーキテクチャ", "データモデル"]),
    ("TST", ["test", "pytest", "verification", "テスト", "試験", "検証"]),
    ("REL", ["release", "changelog", "配布", "リリース", "変更履歴"]),
    ("ARC", ["archive", "obsolete", "deprecated", "旧版", "凍結", "アーカイブ"]),
    ("DEV", ["src", "source", "implementation", "development", "code", "実装", "開発", "ソース"]),
]

EXTENSION_HINTS = {
    ".py": "DEV", ".swift": "DEV", ".js": "DEV", ".ts": "DEV", ".java": "DEV",
    ".c": "DEV", ".cpp": "DEV", ".h": "DEV", ".cs": "DEV",
}

@dataclass(frozen=True)
class ClassificationRecord:
    document_id: str
    original_path: str
    proposed_category: str
    proposed_folder: str
    confidence: float
    method: str
    reason: str
    review_status: str = "proposed"
    confirmed_category: str | None = None


def _normalize(text: str) -> str:
    return re.sub(r"[\s_\-./\\]+", " ", text.casefold())


def classify_path(path: str) -> tuple[str, float, str, str]:
    p = PurePosixPath(path.replace("\\", "/"))
    normalized = _normalize(path)
    ext = p.suffix.casefold()
    if ext in EXTENSION_HINTS:
        cat = EXTENSION_HINTS[ext]
        return cat, 0.96, "extension", f"拡張子 {ext} を開発資産として判定"

    scores: dict[str, list[str]] = {}
    for category, keywords in RULES:
        matched = [kw for kw in keywords if kw.casefold() in normalized]
        if matched:
            scores[category] = matched
    if not scores:
        return "UNK", 0.25, "fallback", "一致する分類ルールなし"

    ranked = sorted(scores.items(), key=lambda x: (len(x[1]), max(map(len, x[1]))), reverse=True)
    category, matched = ranked[0]
    confidence = min(0.99, 0.72 + 0.08 * len(matched))
    return category, confidence, "rule", "キーワード一致: " + ", ".join(matched)


def classify_manifest(manifest: dict) -> list[ClassificationRecord]:
    records: list[ClassificationRecord] = []
    for file in manifest.get("files", []):
        path = file["original_path"]
        category, confidence, method, reason = classify_path(path)
        records.append(ClassificationRecord(
            document_id=file["sha256"],
            original_path=path,
            proposed_category=category,
            proposed_folder=DEFAULT_CATEGORIES[category],
            confidence=confidence,
            method=method,
            reason=reason,
        ))
    return records


def apply_review(records: list[ClassificationRecord], decisions: dict[str, str]) -> list[ClassificationRecord]:
    reviewed: list[ClassificationRecord] = []
    for r in records:
        category = decisions.get(r.document_id)
        if category is not None and category not in DEFAULT_CATEGORIES:
            raise ValueError(f"未知のカテゴリです: {category}")
        data = asdict(r)
        if category is not None:
            data["confirmed_category"] = category
            data["review_status"] = "confirmed" if category == r.proposed_category else "overridden"
        reviewed.append(ClassificationRecord(**data))
    return reviewed


def write_classification_outputs(package_root: str | Path, records: list[ClassificationRecord]) -> dict:
    root = Path(package_root)
    adm = root / "_ADM"
    adm.mkdir(parents=True, exist_ok=True)
    data = [asdict(r) for r in records]
    report = {
        "schemaVersion": "1.0",
        "recordCount": len(data),
        "confirmedCount": sum(r["review_status"] in {"confirmed", "overridden"} for r in data),
        "unclassifiedCount": sum((r["confirmed_category"] or r["proposed_category"]) == "UNK" for r in data),
        "records": data,
    }
    (adm / "classification_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    with (adm / "classification_review.csv").open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(data[0].keys()) if data else ["document_id"])
        writer.writeheader()
        writer.writerows(data)
    return report
