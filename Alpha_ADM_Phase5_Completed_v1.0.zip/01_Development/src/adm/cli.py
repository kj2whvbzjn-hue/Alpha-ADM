from __future__ import annotations

import argparse
import json
import sys

from .config import load_config
from .verifier import verify_package
from .workflow import import_and_classify
from .zip_importer import ZipValidationError


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='Alpha Document Manager importer/classifier/organizer/verifier')
    parser.add_argument('zip_path', nargs='?')
    parser.add_argument('workspace', nargs='?')
    parser.add_argument('--decisions', help='document_idと確定カテゴリのJSON')
    parser.add_argument('--config', help='実行上限・バッファ・ログレベルを指定するJSON')
    parser.add_argument('--export-organized', action='store_true', help='分類別に整理したZIPも生成する')
    parser.add_argument('--verify-package', help='既存パッケージの整合性を検証する')
    args = parser.parse_args(argv)
    try:
        if args.verify_package:
            result = verify_package(args.verify_package)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0 if result['status'] == 'valid' else 3
        if not args.zip_path or not args.workspace:
            parser.error('zip_path と workspace を指定するか、--verify-package を使用してください。')
        result = import_and_classify(
            args.zip_path,
            args.workspace,
            args.decisions,
            export_organized=args.export_organized,
            config=load_config(args.config),
        )
    except (OSError, ValueError, ZipValidationError, json.JSONDecodeError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
