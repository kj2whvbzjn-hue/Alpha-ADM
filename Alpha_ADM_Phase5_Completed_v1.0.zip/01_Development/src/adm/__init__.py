"""Alpha Document Manager Phase 4 core."""
__version__ = '4.0.0'
