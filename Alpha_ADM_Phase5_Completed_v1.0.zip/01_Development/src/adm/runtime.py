from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class RunMetrics:
    started_at: float = field(default_factory=time.perf_counter)
    validation_seconds: float = 0.0
    extraction_seconds: float = 0.0
    classification_seconds: float = 0.0
    export_seconds: float = 0.0
    file_count: int = 0
    total_bytes: int = 0

    def finish(self) -> dict:
        total_seconds = time.perf_counter() - self.started_at
        throughput = self.total_bytes / total_seconds if total_seconds else 0.0
        return {
            'schemaVersion': '1.0',
            'fileCount': self.file_count,
            'totalBytes': self.total_bytes,
            'totalSeconds': round(total_seconds, 6),
            'validationSeconds': round(self.validation_seconds, 6),
            'extractionSeconds': round(self.extraction_seconds, 6),
            'classificationSeconds': round(self.classification_seconds, 6),
            'exportSeconds': round(self.export_seconds, 6),
            'throughputBytesPerSecond': round(throughput, 2),
        }


def configure_logging(log_path: Path, level: str) -> logging.Logger:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger('adm')
    logger.setLevel(getattr(logging, level))
    logger.handlers.clear()
    handler = logging.FileHandler(log_path, encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    logger.addHandler(handler)
    return logger


def write_metrics(path: Path, metrics: dict) -> None:
    path.write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding='utf-8')
