from __future__ import annotations

import hashlib
import json
import mimetypes
import os
import shutil
import stat
import time
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath


class ZipValidationError(ValueError):
    """Raised when an archive violates ADM safety rules."""


@dataclass(frozen=True)
class ImportLimits:
    max_members: int = 10_000
    max_total_uncompressed: int = 1_000_000_000
    max_single_file: int = 250_000_000
    max_compression_ratio: float = 200.0


@dataclass(frozen=True)
class FileRecord:
    original_path: str
    extracted_path: str
    size: int
    compressed_size: int
    sha256: str
    mime_type: str


def _safe_relative_path(name: str) -> Path:
    normalized = name.replace('\\', '/')
    p = PurePosixPath(normalized)
    if not normalized or normalized.endswith('/'):
        return Path(*p.parts)
    if p.is_absolute() or any(part in {'', '.', '..'} for part in p.parts):
        raise ZipValidationError(f'危険なパスを拒否しました: {name}')
    if p.parts and ':' in p.parts[0]:
        raise ZipValidationError(f'ドライブ指定を拒否しました: {name}')
    return Path(*p.parts)


def _is_symlink(info: zipfile.ZipInfo) -> bool:
    return stat.S_ISLNK(info.external_attr >> 16)


def _sha256_file(path: Path, chunk_size: int) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def validate_archive(zip_path: Path, limits: ImportLimits = ImportLimits()) -> list[zipfile.ZipInfo]:
    if zip_path.suffix.lower() != '.zip':
        raise ZipValidationError('ZIP形式のファイルを指定してください。')
    if not zipfile.is_zipfile(zip_path):
        raise ZipValidationError('有効なZIPファイルではありません。')
    with zipfile.ZipFile(zip_path) as archive:
        infos = archive.infolist()
        if len(infos) > limits.max_members:
            raise ZipValidationError('ファイル件数が上限を超えています。')
        total = 0
        for info in infos:
            _safe_relative_path(info.filename)
            if info.flag_bits & 0x1:
                raise ZipValidationError('暗号化ZIPは受け付けません。')
            if _is_symlink(info):
                raise ZipValidationError(f'シンボリックリンクを拒否しました: {info.filename}')
            if info.file_size > limits.max_single_file:
                raise ZipValidationError(f'単一ファイル上限超過: {info.filename}')
            total += info.file_size
            if total > limits.max_total_uncompressed:
                raise ZipValidationError('展開後総容量が上限を超えています。')
            if info.file_size and info.compress_size == 0:
                raise ZipValidationError(f'異常な圧縮情報: {info.filename}')
            if info.compress_size and info.file_size / info.compress_size > limits.max_compression_ratio:
                raise ZipValidationError(f'圧縮率が高すぎます: {info.filename}')
        return infos


def import_zip(
    zip_path: str | Path,
    workspace: str | Path,
    limits: ImportLimits = ImportLimits(),
    *,
    buffer_size: int = 1024 * 1024,
    logger=None,
    metrics=None,
) -> dict:
    source = Path(zip_path).resolve()
    root = Path(workspace).resolve()
    root.mkdir(parents=True, exist_ok=True)
    source_sha256 = _sha256_file(source, buffer_size)
    package_id = source_sha256[:16]
    package_root = root / package_id
    extract_root = package_root / 'extracted'
    if package_root.exists():
        shutil.rmtree(package_root)
    extract_root.mkdir(parents=True)

    t0 = time.perf_counter()
    infos = validate_archive(source, limits)
    if metrics is not None:
        metrics.validation_seconds = time.perf_counter() - t0
    if logger:
        logger.info('archive_validated source=%s members=%d', source, len(infos))

    t0 = time.perf_counter()
    records: list[FileRecord] = []
    with zipfile.ZipFile(source) as archive:
        for info in infos:
            rel = _safe_relative_path(info.filename)
            target = (extract_root / rel).resolve()
            if os.path.commonpath([str(extract_root), str(target)]) != str(extract_root):
                raise ZipValidationError(f'展開先逸脱を拒否しました: {info.filename}')
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256()
            with archive.open(info, 'r') as src, target.open('wb') as dst:
                while chunk := src.read(buffer_size):
                    dst.write(chunk)
                    digest.update(chunk)
            mime, _ = mimetypes.guess_type(target.name)
            records.append(FileRecord(
                original_path=info.filename,
                extracted_path=str(target.relative_to(package_root)),
                size=info.file_size,
                compressed_size=info.compress_size,
                sha256=digest.hexdigest(),
                mime_type=mime or 'application/octet-stream',
            ))
    if metrics is not None:
        metrics.extraction_seconds = time.perf_counter() - t0
        metrics.file_count = len(records)
        metrics.total_bytes = sum(r.size for r in records)
    if logger:
        logger.info('archive_extracted package_id=%s files=%d bytes=%d', package_id, len(records), sum(r.size for r in records))

    manifest = {
        'schemaVersion': '1.1',
        'packageId': package_id,
        'sourceArchiveName': source.name,
        'sourceArchiveSha256': source_sha256,
        'status': 'phase1_imported',
        'fileCount': len(records),
        'totalSize': sum(r.size for r in records),
        'files': [asdict(r) for r in records],
    }
    adm_dir = package_root / '_ADM'
    adm_dir.mkdir()
    (adm_dir / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    return manifest
