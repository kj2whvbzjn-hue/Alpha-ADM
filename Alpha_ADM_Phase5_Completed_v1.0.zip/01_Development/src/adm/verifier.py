from __future__ import annotations

import hashlib
import json
from pathlib import Path


def _sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as fh:
        while chunk := fh.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def verify_package(package_root: str | Path) -> dict:
    root = Path(package_root).resolve()
    manifest_path = root / '_ADM' / 'manifest.json'
    if not manifest_path.exists():
        raise ValueError(f'マニフェストが見つかりません: {manifest_path}')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))

    expected_paths: set[str] = set()
    missing: list[str] = []
    modified: list[dict] = []
    verified = 0
    for item in manifest.get('files', []):
        rel = item['extracted_path'].replace('\\', '/')
        expected_paths.add(rel)
        path = root / rel
        if not path.is_file():
            missing.append(rel)
            continue
        actual_size = path.stat().st_size
        actual_hash = _sha256(path)
        if actual_size != item['size'] or actual_hash != item['sha256']:
            modified.append({
                'path': rel,
                'expectedSize': item['size'],
                'actualSize': actual_size,
                'expectedSha256': item['sha256'],
                'actualSha256': actual_hash,
            })
        else:
            verified += 1

    extract_root = root / 'extracted'
    actual_paths = {
        path.relative_to(root).as_posix()
        for path in extract_root.rglob('*')
        if path.is_file()
    } if extract_root.exists() else set()
    unexpected = sorted(actual_paths - expected_paths)

    result = {
        'schemaVersion': '1.0',
        'packageId': manifest.get('packageId'),
        'status': 'valid' if not (missing or modified or unexpected) else 'invalid',
        'expectedFileCount': len(expected_paths),
        'verifiedFileCount': verified,
        'missing': sorted(missing),
        'modified': modified,
        'unexpected': unexpected,
    }
    (root / '_ADM' / 'integrity_report.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8'
    )
    return result
