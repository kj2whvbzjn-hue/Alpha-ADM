from pathlib import Path
import json
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).parents[1] / "src"))
from adm.classifier import apply_review, classify_manifest, classify_path
from adm.workflow import import_and_classify


def make_zip(path: Path, entries: dict[str, bytes]) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for name, data in entries.items():
            z.writestr(name, data)


def test_classify_rules():
    assert classify_path("docs/要件定義書.docx")[0] == "REQ"
    assert classify_path("src/main.py")[0] == "DEV"
    assert classify_path("監査/品質報告.pdf")[0] == "AUD"


def test_unknown_fallback():
    category, confidence, method, _ = classify_path("misc/random.bin")
    assert category == "UNK"
    assert confidence < 0.5
    assert method == "fallback"


def test_review_override():
    manifest = {"files": [{"original_path":"random.bin", "sha256":"abc"}]}
    records = classify_manifest(manifest)
    reviewed = apply_review(records, {"abc":"ARC"})
    assert reviewed[0].confirmed_category == "ARC"
    assert reviewed[0].review_status == "overridden"


def test_import_and_classify_outputs(tmp_path: Path):
    zp = tmp_path / "sample.zip"
    make_zip(zp, {"要件/要件定義書.txt": b"req", "src/main.py": b"print(1)", "misc/x.bin": b"x"})
    manifest = import_and_classify(zp, tmp_path / "work")
    root = tmp_path / "work" / manifest["packageId"] / "_ADM"
    report = json.loads((root / "classification_report.json").read_text(encoding="utf-8"))
    assert report["recordCount"] == 3
    assert (root / "classification_review.csv").exists()
    assert manifest["status"] == "phase2_classified"


def test_export_organized_zip(tmp_path: Path):
    zp = tmp_path / 'sample.zip'
    make_zip(zp, {
        'requirements/report.txt': b'a',
        'other/要件_report.txt': b'b',
        'src/main.py': b'print(1)',
    })
    manifest = import_and_classify(zp, tmp_path / 'work', export_organized=True)
    output = Path(manifest['organizationOutput']['organizedArchive'])
    assert output.exists()
    with zipfile.ZipFile(output) as archive:
        names = set(archive.namelist())
    assert '03_Requirements/report.txt' in names
    assert '03_Requirements/要件_report.txt' in names
    assert '01_Development/main.py' in names
    assert '_ADM/organization_index.json' in names


def test_export_renames_duplicate_basenames(tmp_path: Path):
    zp = tmp_path / 'sample.zip'
    make_zip(zp, {'要件/a.txt': b'a', 'requirements/a.txt': b'b'})
    manifest = import_and_classify(zp, tmp_path / 'work', export_organized=True)
    with zipfile.ZipFile(manifest['organizationOutput']['organizedArchive']) as archive:
        names = set(archive.namelist())
    assert '03_Requirements/a.txt' in names
    assert '03_Requirements/a_2.txt' in names


def test_reproducible_export(tmp_path: Path):
    zp = tmp_path / 'sample.zip'
    make_zip(zp, {'要件/a.txt': b'a', 'src/main.py': b'print(1)'})
    first = import_and_classify(zp, tmp_path / 'work', export_organized=True)
    first_zip = Path(first['organizationOutput']['organizedArchive'])
    first_hash = first['organizationOutput']['organizedArchiveSha256']
    second = import_and_classify(zp, tmp_path / 'work', export_organized=True)
    assert second['organizationOutput']['organizedArchiveSha256'] == first_hash
    assert first_zip.exists()
