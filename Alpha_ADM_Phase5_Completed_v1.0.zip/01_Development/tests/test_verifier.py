from pathlib import Path
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).parents[1] / 'src'))
from adm.verifier import verify_package
from adm.zip_importer import import_zip


def make_zip(path: Path, entries: dict[str, bytes]) -> None:
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for name, data in entries.items():
            z.writestr(name, data)


def test_verify_valid_package(tmp_path: Path):
    zp = tmp_path / 'sample.zip'
    make_zip(zp, {'docs/a.txt': b'hello'})
    manifest = import_zip(zp, tmp_path / 'work')
    result = verify_package(tmp_path / 'work' / manifest['packageId'])
    assert result['status'] == 'valid'
    assert result['verifiedFileCount'] == 1


def test_verify_detects_modified_missing_and_unexpected(tmp_path: Path):
    zp = tmp_path / 'sample.zip'
    make_zip(zp, {'a.txt': b'a', 'b.txt': b'b'})
    manifest = import_zip(zp, tmp_path / 'work')
    root = tmp_path / 'work' / manifest['packageId']
    (root / 'extracted/a.txt').write_bytes(b'changed')
    (root / 'extracted/b.txt').unlink()
    (root / 'extracted/extra.txt').write_bytes(b'x')
    result = verify_package(root)
    assert result['status'] == 'invalid'
    assert result['modified'][0]['path'] == 'extracted/a.txt'
    assert result['missing'] == ['extracted/b.txt']
    assert result['unexpected'] == ['extracted/extra.txt']
