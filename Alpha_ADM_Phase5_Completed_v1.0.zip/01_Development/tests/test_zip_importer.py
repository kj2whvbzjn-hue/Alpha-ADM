from pathlib import Path
import sys
import zipfile

import pytest

sys.path.insert(0, str(Path(__file__).parents[1] / "src"))
from adm.zip_importer import ZipValidationError, import_zip


def make_zip(path: Path, entries: dict[str, bytes]) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for name, data in entries.items():
            z.writestr(name, data)


def test_import_normal_zip(tmp_path: Path):
    zp = tmp_path / "normal.zip"
    make_zip(zp, {"docs/a.txt": b"hello", "b.json": b"{}"})
    manifest = import_zip(zp, tmp_path / "work")
    assert manifest["fileCount"] == 2
    package = tmp_path / "work" / manifest["packageId"]
    assert (package / "extracted/docs/a.txt").read_bytes() == b"hello"
    assert (package / "_ADM/manifest.json").exists()


def test_reject_zip_slip(tmp_path: Path):
    zp = tmp_path / "bad.zip"
    make_zip(zp, {"../escape.txt": b"bad"})
    with pytest.raises(ZipValidationError):
        import_zip(zp, tmp_path / "work")


def test_reject_absolute_path(tmp_path: Path):
    zp = tmp_path / "bad.zip"
    make_zip(zp, {"/root.txt": b"bad"})
    with pytest.raises(ZipValidationError):
        import_zip(zp, tmp_path / "work")


def test_runtime_config_and_metrics(tmp_path: Path):
    import json
    from adm.config import load_config
    from adm.workflow import import_and_classify

    config_path = tmp_path / 'config.json'
    config_path.write_text(json.dumps({
        'buffer_size': 8192,
        'log_level': 'DEBUG',
        'limits': {'max_members': 10}
    }), encoding='utf-8')
    config = load_config(config_path)
    zp = tmp_path / 'normal.zip'
    make_zip(zp, {'docs/a.txt': b'hello'})
    manifest = import_and_classify(zp, tmp_path / 'work', config=config)
    adm = tmp_path / 'work' / manifest['packageId'] / '_ADM'
    metrics = json.loads((adm / 'run_metrics.json').read_text(encoding='utf-8'))
    assert metrics['fileCount'] == 1
    assert metrics['totalBytes'] == 5
    assert (adm / 'execution.log').exists()
    assert manifest['runtimeConfig']['bufferSize'] == 8192


def test_config_rejects_invalid_buffer(tmp_path: Path):
    import json
    from adm.config import load_config

    path = tmp_path / 'bad.json'
    path.write_text(json.dumps({'buffer_size': 1}), encoding='utf-8')
    with pytest.raises(ValueError):
        load_config(path)
