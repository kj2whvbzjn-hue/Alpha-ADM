# Alpha ADM Phase5

安全なZIP取込、ルール分類、レビュー反映、再現可能な整理済みZIP出力、整合性検証に加え、Phase5では運用ログ、実行統計、JSON設定を追加しました。

## 実行例

```bash
PYTHONPATH=src python -m adm.cli input.zip workspace --export-organized
PYTHONPATH=src python -m adm.cli input.zip workspace --config adm_config.json
PYTHONPATH=src python -m adm.cli --verify-package workspace/<packageId>
```

## 設定例

```json
{
  "buffer_size": 1048576,
  "log_level": "INFO",
  "limits": {
    "max_members": 10000,
    "max_total_uncompressed": 1000000000,
    "max_single_file": 250000000,
    "max_compression_ratio": 200.0
  }
}
```

実行後、`_ADM/execution.log`、`_ADM/run_metrics.json`、`_ADM/manifest.json` を確認してください。既存の `status` 値は互換性のため維持し、実装世代は `implementationPhase` で示します。
