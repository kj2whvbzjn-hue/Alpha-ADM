# Alpha Document Manager Phase 3 Completed v1.0

## 追加内容
- 分類結果に基づく `organized/` の生成
- 整理済み `<packageId>_organized.zip` の生成
- 同名ファイルの連番リネームによる上書き防止
- `_ADM/organization_index.json` の生成
- `decisions.json` の型検証
- Phase 1・2を含む回帰テスト拡充

## 実行

```bash
python -m adm.cli input.zip workspace --export-organized
python -m adm.cli input.zip workspace --decisions decisions.json --export-organized
```

## 品質結果
- pytest: 9 passed
- 原本ZIP: 非変更
- DOCX: 日本語表示をレンダリング確認済み
