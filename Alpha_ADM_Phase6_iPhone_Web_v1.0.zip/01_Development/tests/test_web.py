from adm.web import _parse_multipart


def test_parse_multipart_zip_and_export():
    boundary = '----alpha-boundary'
    body = (
        f'--{boundary}\r\nContent-Disposition: form-data; name="archive"; filename="sample.zip"\r\n'
        'Content-Type: application/zip\r\n\r\n'
    ).encode() + b'PK\x03\x04demo' + (
        f'\r\n--{boundary}\r\nContent-Disposition: form-data; name="export"\r\n\r\non'
        f'\r\n--{boundary}--\r\n'
    ).encode()
    name, payload, export = _parse_multipart(f'multipart/form-data; boundary={boundary}', body)
    assert name == 'sample.zip'
    assert payload == b'PK\x03\x04demo'
    assert export is True
