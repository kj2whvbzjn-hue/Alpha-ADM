# Alpha ADM Phase6

Phase5のCLI機能に加え、iPhoneのSafariから操作できるレスポンシブWeb画面を追加しました。元ZIPは変更せず、アップロードされた一時ファイルは処理終了時に削除します。

## Web画面の起動

```bash
PYTHONPATH=src python -m adm.web --host 0.0.0.0 --port 8080
```

同じWi-FiのiPhoneから、起動したPCまたはサーバーのIPアドレスへアクセスします。例: `http://192.168.1.20:8080`

> iPhone単体ではPythonサーバーを常時実行できないため、この版はPC・NAS・クラウドなどに置き、iPhoneはSafariを操作画面として使用します。インターネット公開時はHTTPS、認証、アクセス制限を必ず追加してください。

## CLI

```bash
PYTHONPATH=src python -m adm.cli input.zip workspace --export-organized
PYTHONPATH=src python -m adm.cli --verify-package workspace/<packageId>
```
