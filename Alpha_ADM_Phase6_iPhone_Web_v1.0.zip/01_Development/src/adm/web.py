from __future__ import annotations

import argparse
import html
import json
import shutil
import tempfile
from email.parser import BytesParser
from email.policy import default
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from .config import RuntimeConfig, load_config
from .workflow import import_and_classify
from .zip_importer import ZipValidationError

_PAGE = '''<!doctype html>
<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Alpha ADM</title><style>
:root{font-family:-apple-system,BlinkMacSystemFont,"Hiragino Sans",sans-serif;color:#172033;background:#f4f6fa}
body{margin:0}.wrap{max-width:680px;margin:auto;padding:24px 16px 48px}.card{background:#fff;border-radius:18px;padding:22px;box-shadow:0 8px 30px #18213a18}
h1{font-size:28px;margin:0 0 8px}.sub{color:#5d6678;line-height:1.6;margin:0 0 22px}.drop{display:block;border:2px dashed #9ba7bd;border-radius:16px;padding:24px;text-align:center;background:#fafbfe}
input[type=file]{width:100%;font-size:16px}.check{display:flex;gap:10px;align-items:center;margin:20px 0}button{width:100%;border:0;border-radius:14px;padding:16px;font-size:18px;font-weight:700;background:#2457d6;color:#fff}
button:disabled{opacity:.55}.note{font-size:13px;color:#687184;line-height:1.55;margin-top:16px}.status{margin-top:18px;white-space:pre-wrap;line-height:1.55}.error{color:#b42318}.ok{color:#067647}
</style></head><body><main class="wrap"><section class="card"><h1>Alpha ADM</h1><p class="sub">iPhoneの「ファイル」からZIPを選び、分類・整理したZIPを作成します。</p>
<form id="form" method="post" action="/process" enctype="multipart/form-data"><label class="drop">処理するZIP<br><br><input id="zip" name="archive" type="file" accept=".zip,application/zip" required></label>
<label class="check"><input type="checkbox" name="export" checked> 分類別に整理したZIPを作成</label><button id="run" type="submit">整理を開始</button></form>
<div id="status" class="status"></div><p class="note">処理中はこの画面を閉じないでください。元のZIPは変更されません。暗号化ZIPや安全上問題のあるZIPは拒否されます。</p></section></main>
<script>const f=document.getElementById('form'),b=document.getElementById('run'),s=document.getElementById('status');f.addEventListener('submit',async e=>{e.preventDefault();b.disabled=true;s.className='status';s.textContent='処理中です…';try{const r=await fetch('/process',{method:'POST',body:new FormData(f)});if(!r.ok){const t=await r.text();throw new Error(t||'処理に失敗しました');}const blob=await r.blob();let name='alpha_adm_result.zip';const cd=r.headers.get('content-disposition')||'';const m=cd.match(/filename="([^"]+)"/);if(m)name=m[1];const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),30000);s.className='status ok';s.textContent='完了しました。ダウンロードを確認してください。';}catch(err){s.className='status error';s.textContent='エラー: '+err.message;}finally{b.disabled=false;}});</script>
</body></html>'''


def _parse_multipart(content_type: str, body: bytes) -> tuple[str, bytes, bool]:
    message = BytesParser(policy=default).parsebytes(
        f'Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n'.encode() + body
    )
    filename = ''
    payload = b''
    export = False
    for part in message.iter_parts():
        name = part.get_param('name', header='content-disposition')
        if name == 'archive':
            filename = Path(part.get_filename() or 'upload.zip').name
            payload = part.get_payload(decode=True) or b''
        elif name == 'export':
            export = True
    if not payload:
        raise ValueError('ZIPファイルが選択されていません。')
    return filename, payload, export


class AdmWebHandler(BaseHTTPRequestHandler):
    server_version = 'AlphaADM/6.0'

    def do_GET(self) -> None:
        if urlparse(self.path).path != '/':
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        data = _PAGE.encode('utf-8')
        self.send_response(HTTPStatus.OK)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self) -> None:
        if urlparse(self.path).path != '/process':
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            max_upload = self.server.max_upload_bytes  # type: ignore[attr-defined]
            if length <= 0 or length > max_upload:
                raise ValueError(f'アップロード容量は最大{max_upload // (1024*1024)}MBです。')
            filename, payload, export = _parse_multipart(
                self.headers.get('Content-Type', ''), self.rfile.read(length)
            )
            if not filename.lower().endswith('.zip'):
                raise ValueError('ZIP形式のファイルを選択してください。')
            with tempfile.TemporaryDirectory(prefix='alpha_adm_web_') as td:
                root = Path(td)
                source = root / filename
                source.write_bytes(payload)
                workspace = root / 'workspace'
                manifest = import_and_classify(
                    source, workspace, export_organized=export, config=self.server.runtime_config  # type: ignore[attr-defined]
                )
                package = workspace / manifest['packageId']
                if export:
                    result = Path(manifest['organizationOutput']['organizedArchive'])
                else:
                    result = shutil.make_archive(str(root / f"{manifest['packageId']}_package"), 'zip', package)
                    result = Path(result)
                data = result.read_bytes()
                download_name = result.name
            self.send_response(HTTPStatus.OK)
            self.send_header('Content-Type', 'application/zip')
            self.send_header('Content-Disposition', f'attachment; filename="{download_name}"')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except (OSError, ValueError, ZipValidationError, json.JSONDecodeError) as exc:
            data = html.escape(str(exc)).encode('utf-8')
            self.send_response(HTTPStatus.BAD_REQUEST)
            self.send_header('Content-Type', 'text/plain; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    def log_message(self, fmt: str, *args: object) -> None:
        print(f'[web] {self.address_string()} - {fmt % args}')


def run_server(host: str, port: int, config: RuntimeConfig, max_upload_mb: int = 300) -> None:
    server = ThreadingHTTPServer((host, port), AdmWebHandler)
    server.runtime_config = config  # type: ignore[attr-defined]
    server.max_upload_bytes = max_upload_mb * 1024 * 1024  # type: ignore[attr-defined]
    print(f'Alpha ADM Web: http://{host}:{port}')
    server.serve_forever()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='Alpha ADM iPhone-compatible web interface')
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8080)
    parser.add_argument('--config')
    parser.add_argument('--max-upload-mb', type=int, default=300)
    args = parser.parse_args(argv)
    run_server(args.host, args.port, load_config(args.config), args.max_upload_mb)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
