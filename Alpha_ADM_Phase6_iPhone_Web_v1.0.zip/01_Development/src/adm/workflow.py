from __future__ import annotations

import json
import time
from pathlib import Path

from .classifier import apply_review, classify_manifest, write_classification_outputs
from .config import RuntimeConfig
from .exporter import export_organized_package
from .runtime import RunMetrics, configure_logging, write_metrics
from .zip_importer import import_zip


def _load_decisions(path: str | Path) -> dict[str, str]:
    raw = json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(raw, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in raw.items()):
        raise ValueError('decisions.json は document_id とカテゴリ文字列のJSONオブジェクトにしてください。')
    return raw


def import_and_classify(
    zip_path: str | Path,
    workspace: str | Path,
    decisions_path: str | Path | None = None,
    export_organized: bool = False,
    config: RuntimeConfig | None = None,
) -> dict:
    config = config or RuntimeConfig()
    metrics = RunMetrics()
    temp_log = Path(workspace).resolve() / '_ADM_phase5.log'
    logger = configure_logging(temp_log, config.log_level)
    logger.info('run_started zip=%s workspace=%s export=%s', zip_path, workspace, export_organized)
    manifest = import_zip(
        zip_path, workspace, config.limits, buffer_size=config.buffer_size, logger=logger, metrics=metrics
    )
    package_root = Path(workspace).resolve() / manifest['packageId']
    adm_dir = package_root / '_ADM'
    final_log = adm_dir / 'execution.log'
    temp_log.replace(final_log)
    logger = configure_logging(final_log, config.log_level)

    t0 = time.perf_counter()
    records = classify_manifest(manifest)
    if decisions_path:
        records = apply_review(records, _load_decisions(decisions_path))
    report = write_classification_outputs(package_root, records)
    metrics.classification_seconds = time.perf_counter() - t0
    manifest['status'] = 'phase3_organized' if export_organized else 'phase2_classified'
    manifest['implementationPhase'] = 6
    manifest['classificationSummary'] = {
        'recordCount': report['recordCount'],
        'confirmedCount': report['confirmedCount'],
        'unclassifiedCount': report['unclassifiedCount'],
    }
    if export_organized:
        t0 = time.perf_counter()
        manifest['organizationOutput'] = export_organized_package(package_root, records)
        metrics.export_seconds = time.perf_counter() - t0
    run_metrics = metrics.finish()
    write_metrics(adm_dir / 'run_metrics.json', run_metrics)
    manifest['runtimeMetrics'] = run_metrics
    manifest['runtimeConfig'] = {
        'bufferSize': config.buffer_size,
        'logLevel': config.log_level,
        'limits': config.limits.__dict__,
    }
    (adm_dir / 'manifest.json').write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8'
    )
    logger.info('run_completed status=%s seconds=%s', manifest['status'], run_metrics['totalSeconds'])
    return manifest
